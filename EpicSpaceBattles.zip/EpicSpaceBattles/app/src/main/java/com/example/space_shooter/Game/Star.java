package com.example.space_shooter.Game;

public class Star {
    public float x, y;
    public int skinId = 1;
}
