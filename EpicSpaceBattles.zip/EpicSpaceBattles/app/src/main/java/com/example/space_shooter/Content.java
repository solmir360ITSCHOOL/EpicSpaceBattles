package com.example.space_shooter;
import com.example.space_shooter.Game.Player;
import com.example.space_shooter.main.StartFront;

public class Content {
    public static StartFront space = new StartFront(true);
    public static Player player = new Player();
    public static GameInfo info = new GameInfo();
}
